"use client"

import { useState, useCallback } from "react"
import { StockHeader } from "@/components/stock-header"
import { SessionStats } from "@/components/session-stats"
import { QuickCount } from "@/components/quick-count"
import { StockTable } from "@/components/stock-table"
import { TeamPanel } from "@/components/team-panel"
import { ActivityFeed } from "@/components/activity-feed"
import { ZoneProgress } from "@/components/zone-progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  mockSession,
  mockStockItems,
  mockTeamMembers,
  mockActivityFeed,
} from "@/lib/stock-store"
import type { StockSession, StockItem } from "@/lib/stock-store"
import {
  LayoutGrid,
  ScanBarcode,
  Table2,
  Users,
  Activity,
  MapPin,
} from "lucide-react"

export default function StockTakeDashboard() {
  const [session, setSession] = useState<StockSession>(mockSession)
  const [items, setItems] = useState<StockItem[]>(mockStockItems)
  const [activeTab, setActiveTab] = useState("dashboard")

  const handleToggleSession = useCallback(() => {
    setSession((prev) => ({
      ...prev,
      status: prev.status === "live" ? "paused" : "live",
    }))
  }, [])

  const handleUpdateCount = useCallback(
    (id: string, qty: number) => {
      setItems((prev) =>
        prev.map((item) => {
          if (item.id !== id) return item
          const variance = qty - item.expectedQty
          return {
            ...item,
            countedQty: qty,
            variance,
            status: variance === 0 ? "counted" : "variance",
            lastCountedBy: "You",
            lastCountedAt: new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          }
        })
      )
      // Update session stats
      setSession((prev) => {
        const counted = items.filter(
          (i) => i.id === id || i.status !== "pending"
        ).length
        const variances = items.filter(
          (i) =>
            (i.id === id
              ? qty - i.expectedQty !== 0
              : i.status === "variance")
        ).length
        return {
          ...prev,
          countedItems: Math.min(prev.countedItems + 1, prev.totalItems),
          varianceItems: variances,
        }
      })
    },
    [items]
  )

  const handleSelectItem = useCallback((item: StockItem) => {
    setActiveTab("count")
  }, [])

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <StockHeader session={session} onToggleSession={handleToggleSession} />

      <main className="flex flex-1 flex-col">
        {/* Mobile tab navigation */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="flex flex-1 flex-col"
        >
          <div className="sticky top-[53px] z-40 border-b bg-card/80 backdrop-blur-xl lg:hidden">
            <TabsList className="flex h-auto w-full justify-start gap-0 overflow-x-auto rounded-none bg-transparent p-0">
              <TabsTrigger
                value="dashboard"
                className="flex items-center gap-1.5 rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary"
              >
                <LayoutGrid className="h-3.5 w-3.5" />
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="count"
                className="flex items-center gap-1.5 rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary"
              >
                <ScanBarcode className="h-3.5 w-3.5" />
                Count
              </TabsTrigger>
              <TabsTrigger
                value="items"
                className="flex items-center gap-1.5 rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary"
              >
                <Table2 className="h-3.5 w-3.5" />
                Items
              </TabsTrigger>
              <TabsTrigger
                value="team"
                className="flex items-center gap-1.5 rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary"
              >
                <Users className="h-3.5 w-3.5" />
                Team
              </TabsTrigger>
              <TabsTrigger
                value="activity"
                className="flex items-center gap-1.5 rounded-none border-b-2 border-transparent px-4 py-2.5 text-xs data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary"
              >
                <Activity className="h-3.5 w-3.5" />
                Activity
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Mobile: Dashboard tab */}
          <TabsContent value="dashboard" className="flex-1 p-4 lg:hidden">
            <div className="flex flex-col gap-4">
              <SessionStats session={session} />
              <ZoneProgress />
            </div>
          </TabsContent>

          {/* Mobile: Count tab */}
          <TabsContent value="count" className="flex-1 p-4 lg:hidden">
            <QuickCount items={items} onUpdateCount={handleUpdateCount} />
          </TabsContent>

          {/* Mobile: Items tab */}
          <TabsContent value="items" className="flex-1 p-4 lg:hidden">
            <StockTable items={items} onSelectItem={handleSelectItem} />
          </TabsContent>

          {/* Mobile: Team tab */}
          <TabsContent value="team" className="flex-1 p-4 lg:hidden">
            <div className="flex flex-col gap-4">
              <TeamPanel members={mockTeamMembers} />
              <ZoneProgress />
            </div>
          </TabsContent>

          {/* Mobile: Activity tab */}
          <TabsContent value="activity" className="flex-1 p-4 lg:hidden">
            <ActivityFeed events={mockActivityFeed} />
          </TabsContent>

          {/* Desktop layout */}
          <div className="hidden flex-1 flex-col gap-4 p-4 lg:flex lg:p-6">
            <SessionStats session={session} />

            <div className="grid flex-1 grid-cols-12 gap-4">
              {/* Left sidebar: Quick count + zones */}
              <div className="col-span-3 flex flex-col gap-4">
                <QuickCount items={items} onUpdateCount={handleUpdateCount} />
                <ZoneProgress />
              </div>

              {/* Center: Stock items table */}
              <div className="col-span-6">
                <StockTable items={items} onSelectItem={handleSelectItem} />
              </div>

              {/* Right sidebar: Team + Activity */}
              <div className="col-span-3 flex flex-col gap-4">
                <TeamPanel members={mockTeamMembers} />
                <ActivityFeed events={mockActivityFeed} />
              </div>
            </div>
          </div>
        </Tabs>
      </main>
    </div>
  )
}

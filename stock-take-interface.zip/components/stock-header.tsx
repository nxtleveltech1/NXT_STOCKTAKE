"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import type { StockSession } from "@/lib/stock-store"
import {
  BarChart3,
  ChevronDown,
  Clock,
  Pause,
  Play,
  Radio,
  Settings,
  Users,
  Wifi,
  Menu,
  X,
} from "lucide-react"

function LivePulse() {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
      <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
    </span>
  )
}

function ElapsedTime({ startedAt }: { startedAt: string }) {
  const [elapsed, setElapsed] = useState("")

  useEffect(() => {
    function updateElapsed() {
      const start = new Date(startedAt).getTime()
      const now = Date.now()
      const diff = now - start
      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)
      setElapsed(
        `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
      )
    }
    updateElapsed()
    const interval = setInterval(updateElapsed, 1000)
    return () => clearInterval(interval)
  }, [startedAt])

  return (
    <span className="font-mono text-sm tabular-nums text-muted-foreground">{elapsed}</span>
  )
}

export function StockHeader({
  session,
  onToggleSession,
}: {
  session: StockSession
  onToggleSession: () => void
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b bg-card/80 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 py-3 lg:px-6">
        {/* Left: Logo & Session */}
        <div className="flex items-center gap-3 lg:gap-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <BarChart3 className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="hidden text-lg font-semibold tracking-tight text-foreground sm:inline">
              StockPulse <span className="text-primary">AV</span>
            </span>
          </div>

          <div className="hidden h-6 w-px bg-border md:block" />

          <div className="hidden items-center gap-2 md:flex">
            <Badge
              variant="outline"
              className="gap-1.5 border-primary/30 bg-primary/10 text-primary"
            >
              <LivePulse />
              {session.status === "live" ? "LIVE" : "PAUSED"}
            </Badge>
            <span className="text-sm font-medium text-foreground">{session.id}</span>
            <span className="text-sm text-muted-foreground">{session.name}</span>
          </div>
        </div>

        {/* Center: Timer (desktop) */}
        <div className="hidden items-center gap-3 lg:flex">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <ElapsedTime startedAt={session.startedAt} />
          <div className="h-4 w-px bg-border" />
          <div className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {session.teamMembers} online
            </span>
          </div>
          <div className="h-4 w-px bg-border" />
          <div className="flex items-center gap-1.5">
            <Wifi className="h-3.5 w-3.5 text-primary" />
            <span className="text-xs text-primary">Synced</span>
          </div>
        </div>

        {/* Mobile timer */}
        <div className="flex items-center gap-2 lg:hidden">
          <LivePulse />
          <ElapsedTime startedAt={session.startedAt} />
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="hidden gap-1.5 sm:flex bg-transparent"
            onClick={onToggleSession}
          >
            {session.status === "live" ? (
              <>
                <Pause className="h-3.5 w-3.5" />
                Pause
              </>
            ) : (
              <>
                <Play className="h-3.5 w-3.5" />
                Resume
              </>
            )}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="hidden gap-1.5 sm:flex bg-transparent">
                <Radio className="h-3.5 w-3.5" />
                Actions
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem>Export Progress</DropdownMenuItem>
              <DropdownMenuItem>Generate Report</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Assign Zones</DropdownMenuItem>
              <DropdownMenuItem>Add Team Member</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive">
                End Session
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" className="hidden h-8 w-8 sm:flex">
            <Settings className="h-4 w-4" />
            <span className="sr-only">Settings</span>
          </Button>

          {/* Mobile menu toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 lg:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            <span className="sr-only">Menu</span>
          </Button>
        </div>
      </div>

      {/* Mobile expanded menu */}
      {mobileMenuOpen && (
        <div className="border-t px-4 py-3 lg:hidden">
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <Badge
                variant="outline"
                className="gap-1.5 border-primary/30 bg-primary/10 text-primary"
              >
                <LivePulse />
                {session.status === "live" ? "LIVE" : "PAUSED"}
              </Badge>
              <div className="flex items-center gap-1.5">
                <Wifi className="h-3.5 w-3.5 text-primary" />
                <span className="text-xs text-primary">Synced</span>
              </div>
            </div>
            <div className="text-sm">
              <span className="font-medium text-foreground">{session.id}</span>
              <span className="text-muted-foreground"> - {session.name}</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Users className="h-4 w-4" />
                {session.teamMembers} online
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                {session.location}
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 gap-1.5 bg-transparent"
                onClick={onToggleSession}
              >
                {session.status === "live" ? (
                  <>
                    <Pause className="h-3.5 w-3.5" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5" />
                    Resume
                  </>
                )}
              </Button>
              <Button variant="outline" size="sm" className="flex-1 gap-1.5 bg-transparent">
                <Settings className="h-3.5 w-3.5" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}

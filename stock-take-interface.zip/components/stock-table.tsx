"use client"

import { useState, useMemo } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import type { StockItem } from "@/lib/stock-store"
import { ZONES, CATEGORIES } from "@/lib/stock-store"
import {
  Search,
  Filter,
  ArrowUpDown,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

type SortField = "name" | "sku" | "variance" | "status"
type SortDir = "asc" | "desc"

const statusConfig = {
  pending: {
    label: "Pending",
    icon: Clock,
    className: "border-muted-foreground/30 text-muted-foreground bg-muted-foreground/5",
  },
  counted: {
    label: "Counted",
    icon: CheckCircle2,
    className: "border-chart-2/30 text-chart-2 bg-chart-2/5",
  },
  variance: {
    label: "Variance",
    icon: AlertTriangle,
    className: "border-warning/30 text-warning bg-warning/5",
  },
  verified: {
    label: "Verified",
    icon: ShieldCheck,
    className: "border-primary/30 text-primary bg-primary/5",
  },
} as const

const ITEMS_PER_PAGE = 8

export function StockTable({
  items,
  onSelectItem,
}: {
  items: StockItem[]
  onSelectItem: (item: StockItem) => void
}) {
  const [search, setSearch] = useState("")
  const [zone, setZone] = useState("All Zones")
  const [category, setCategory] = useState("All Categories")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortField, setSortField] = useState<SortField>("status")
  const [sortDir, setSortDir] = useState<SortDir>("asc")
  const [page, setPage] = useState(1)
  const [filtersOpen, setFiltersOpen] = useState(false)

  const filtered = useMemo(() => {
    let result = [...items]

    if (search) {
      const q = search.toLowerCase()
      result = result.filter(
        (item) =>
          item.name.toLowerCase().includes(q) ||
          item.sku.toLowerCase().includes(q) ||
          item.location.toLowerCase().includes(q)
      )
    }

    if (zone !== "All Zones") {
      result = result.filter((item) => item.location.startsWith(zone.split(" - ")[0]))
    }

    if (category !== "All Categories") {
      result = result.filter((item) => item.category === category)
    }

    if (statusFilter !== "all") {
      result = result.filter((item) => item.status === statusFilter)
    }

    const statusOrder = { pending: 0, variance: 1, counted: 2, verified: 3 }
    result.sort((a, b) => {
      let cmp = 0
      switch (sortField) {
        case "name":
          cmp = a.name.localeCompare(b.name)
          break
        case "sku":
          cmp = a.sku.localeCompare(b.sku)
          break
        case "variance":
          cmp = (a.variance ?? 0) - (b.variance ?? 0)
          break
        case "status":
          cmp = statusOrder[a.status] - statusOrder[b.status]
          break
      }
      return sortDir === "asc" ? cmp : -cmp
    })

    return result
  }, [items, search, zone, category, statusFilter, sortField, sortDir])

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE)
  const paginated = filtered.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  )

  function toggleSort(field: SortField) {
    if (sortField === field) {
      setSortDir(sortDir === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDir("asc")
    }
  }

  return (
    <div className="flex flex-col rounded-xl border bg-card">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-4 py-3">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold text-foreground">Stock Items</h2>
          <Badge variant="secondary" className="font-mono text-xs">
            {filtered.length}
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1.5 text-xs lg:hidden"
          onClick={() => setFiltersOpen(!filtersOpen)}
        >
          <Filter className="h-3.5 w-3.5" />
          Filters
        </Button>
      </div>

      {/* Search & Filters */}
      <div className="border-b px-4 py-3">
        <div className="flex flex-col gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search items, SKUs, locations..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setPage(1)
              }}
              className="h-9 bg-secondary/50 pl-9 text-sm"
            />
          </div>

          <div className={`flex-wrap gap-2 ${filtersOpen ? "flex" : "hidden lg:flex"}`}>
            <Select
              value={zone}
              onValueChange={(v) => {
                setZone(v)
                setPage(1)
              }}
            >
              <SelectTrigger className="h-8 w-auto min-w-[140px] bg-secondary/50 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ZONES.map((z) => (
                  <SelectItem key={z} value={z} className="text-xs">
                    {z}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={category}
              onValueChange={(v) => {
                setCategory(v)
                setPage(1)
              }}
            >
              <SelectTrigger className="h-8 w-auto min-w-[140px] bg-secondary/50 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c} className="text-xs">
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-1">
              {(["all", "pending", "counted", "variance", "verified"] as const).map(
                (s) => (
                  <Button
                    key={s}
                    variant={statusFilter === s ? "default" : "outline"}
                    size="sm"
                    className="h-8 text-xs capitalize"
                    onClick={() => {
                      setStatusFilter(s)
                      setPage(1)
                    }}
                  >
                    {s}
                  </Button>
                )
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Table - Desktop */}
      <div className="hidden overflow-x-auto lg:block">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[100px]">
                <button
                  type="button"
                  className="flex items-center gap-1 text-xs"
                  onClick={() => toggleSort("sku")}
                >
                  SKU
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button
                  type="button"
                  className="flex items-center gap-1 text-xs"
                  onClick={() => toggleSort("name")}
                >
                  Product
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead className="text-xs">Location</TableHead>
              <TableHead className="text-right text-xs">Expected</TableHead>
              <TableHead className="text-right text-xs">Counted</TableHead>
              <TableHead className="text-right">
                <button
                  type="button"
                  className="ml-auto flex items-center gap-1 text-xs"
                  onClick={() => toggleSort("variance")}
                >
                  Variance
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead>
                <button
                  type="button"
                  className="flex items-center gap-1 text-xs"
                  onClick={() => toggleSort("status")}
                >
                  Status
                  <ArrowUpDown className="h-3 w-3" />
                </button>
              </TableHead>
              <TableHead className="text-xs">Counted By</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginated.map((item) => {
              const sc = statusConfig[item.status]
              const StatusIcon = sc.icon
              return (
                <TableRow
                  key={item.id}
                  className="cursor-pointer transition-colors hover:bg-secondary/50"
                  onClick={() => onSelectItem(item)}
                >
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {item.sku}
                  </TableCell>
                  <TableCell className="text-sm font-medium text-foreground">
                    {item.name}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {item.location}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm text-foreground">
                    {item.expectedQty}
                  </TableCell>
                  <TableCell className="text-right font-mono text-sm text-foreground">
                    {item.countedQty ?? (
                      <span className="text-muted-foreground">--</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {item.variance !== null ? (
                      <span
                        className={`font-mono text-sm font-medium ${
                          item.variance === 0
                            ? "text-primary"
                            : item.variance > 0
                              ? "text-warning"
                              : "text-destructive"
                        }`}
                      >
                        {item.variance > 0 ? "+" : ""}
                        {item.variance}
                      </span>
                    ) : (
                      <span className="font-mono text-sm text-muted-foreground">
                        --
                      </span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`gap-1 text-xs ${sc.className}`}>
                      <StatusIcon className="h-3 w-3" />
                      {sc.label}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {item.lastCountedBy ? (
                      <div className="flex flex-col">
                        <span className="text-xs text-foreground">
                          {item.lastCountedBy}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {item.lastCountedAt}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">--</span>
                    )}
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      {/* Mobile card list */}
      <div className="flex flex-col lg:hidden">
        {paginated.map((item) => {
          const sc = statusConfig[item.status]
          const StatusIcon = sc.icon
          return (
            <button
              key={item.id}
              type="button"
              className="flex flex-col gap-2 border-b px-4 py-3 text-left transition-colors last:border-b-0 hover:bg-secondary/50"
              onClick={() => onSelectItem(item)}
            >
              <div className="flex items-start justify-between">
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm font-medium text-foreground">
                    {item.name}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {item.sku}
                  </span>
                </div>
                <Badge variant="outline" className={`gap-1 text-xs ${sc.className}`}>
                  <StatusIcon className="h-3 w-3" />
                  {sc.label}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>{item.location}</span>
                <span className="flex items-center gap-1">
                  Exp: <span className="font-mono text-foreground">{item.expectedQty}</span>
                </span>
                <span className="flex items-center gap-1">
                  Cnt:{" "}
                  <span className="font-mono text-foreground">
                    {item.countedQty ?? "--"}
                  </span>
                </span>
                {item.variance !== null && (
                  <span
                    className={`font-mono font-medium ${
                      item.variance === 0
                        ? "text-primary"
                        : item.variance > 0
                          ? "text-warning"
                          : "text-destructive"
                    }`}
                  >
                    {item.variance > 0 ? "+" : ""}
                    {item.variance}
                  </span>
                )}
              </div>
            </button>
          )
        })}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t px-4 py-2.5">
          <span className="text-xs text-muted-foreground">
            Page {page} of {totalPages}
          </span>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              disabled={page <= 1}
              onClick={() => setPage(page - 1)}
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              disabled={page >= totalPages}
              onClick={() => setPage(page + 1)}
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

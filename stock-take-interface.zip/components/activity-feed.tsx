"use client"

import { useState, useEffect, useRef } from "react"
import { Badge } from "@/components/ui/badge"
import type { ActivityEvent } from "@/lib/stock-store"
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  UserPlus,
  MapPin,
} from "lucide-react"

const eventIcons = {
  count: CheckCircle2,
  variance: AlertTriangle,
  verify: ShieldCheck,
  join: UserPlus,
  zone_complete: MapPin,
}

const eventColors = {
  count: "text-chart-2",
  variance: "text-warning",
  verify: "text-primary",
  join: "text-chart-2",
  zone_complete: "text-primary",
}

export function ActivityFeed({
  events: initialEvents,
}: {
  events: ActivityEvent[]
}) {
  const [events, setEvents] = useState(initialEvents)
  const [newEvent, setNewEvent] = useState(false)
  const feedRef = useRef<HTMLDivElement>(null)

  // Simulate live updates
  useEffect(() => {
    const liveMessages = [
      { type: "count" as const, message: "counted 4 OLED TVs in Bay 3", user: "Sarah Chen", zone: "Zone A" },
      { type: "verify" as const, message: "verified Sony A95L 55\" count", user: "James O'Brien", zone: "Zone A" },
      { type: "count" as const, message: "completed HDMI cable rack scan", user: "Tom Nguyen", zone: "Zone E" },
      { type: "variance" as const, message: "flagged variance on AirPods Max (-2)", user: "Priya Patel", zone: "Zone C" },
      { type: "count" as const, message: "counted 6 speakers in Demo Room", user: "Marcus Webb", zone: "Zone B" },
    ]

    let index = 0
    const interval = setInterval(() => {
      const msg = liveMessages[index % liveMessages.length]
      const newEv: ActivityEvent = {
        id: `live-${Date.now()}`,
        ...msg,
        timestamp: "Just now",
      }
      setEvents((prev) => [newEv, ...prev.slice(0, 14)])
      setNewEvent(true)
      setTimeout(() => setNewEvent(false), 300)
      index++
    }, 8000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex flex-col rounded-xl border bg-card">
      <div className="flex items-center justify-between border-b px-4 py-3">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">Live Activity</h2>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          <span className="text-xs text-primary">Live</span>
        </div>
      </div>

      <div
        ref={feedRef}
        className="flex max-h-[400px] flex-col overflow-y-auto scrollbar-thin lg:max-h-[560px]"
      >
        {events.map((event, i) => {
          const Icon = eventIcons[event.type]
          const color = eventColors[event.type]
          return (
            <div
              key={event.id}
              className={`flex gap-3 border-b px-4 py-2.5 last:border-b-0 transition-colors ${
                i === 0 && newEvent ? "bg-primary/5" : "hover:bg-secondary/30"
              }`}
            >
              <div className="mt-0.5 shrink-0">
                <Icon className={`h-4 w-4 ${color}`} />
              </div>
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <p className="text-sm leading-relaxed text-foreground">
                  <span className="font-medium">{event.user}</span>{" "}
                  <span className="text-muted-foreground">{event.message}</span>
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    {event.timestamp}
                  </span>
                  {event.zone && (
                    <Badge
                      variant="outline"
                      className="h-4 px-1 py-0 text-[10px] text-muted-foreground"
                    >
                      {event.zone}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// Simulated real-time stock take data store with mock data
// In production, this would connect to a real-time database like Supabase

export type StockItem = {
  id: string
  sku: string
  name: string
  category: string
  location: string
  expectedQty: number
  countedQty: number | null
  variance: number | null
  status: "pending" | "counted" | "variance" | "verified"
  lastCountedBy: string | null
  lastCountedAt: string | null
}

export type TeamMember = {
  id: string
  name: string
  avatar: string
  role: string
  zone: string
  itemsCounted: number
  status: "active" | "idle" | "offline"
  lastActive: string
}

export type StockSession = {
  id: string
  name: string
  status: "live" | "paused" | "completed"
  startedAt: string
  location: string
  totalItems: number
  countedItems: number
  varianceItems: number
  verifiedItems: number
  teamMembers: number
}

export type ActivityEvent = {
  id: string
  type: "count" | "variance" | "verify" | "join" | "zone_complete"
  message: string
  user: string
  timestamp: string
  zone?: string
}

export const ZONES = [
  "All Zones",
  "Zone A - TV & Display",
  "Zone B - Hi-Fi & Audio",
  "Zone C - Headphones & Portable",
  "Zone D - Home Cinema",
  "Zone E - Cables & Accessories",
  "Zone F - Pro AV & Install",
]

export const CATEGORIES = [
  "All Categories",
  "Televisions",
  "Speakers",
  "Headphones",
  "Soundbars",
  "Turntables & Vinyl",
  "Projectors",
  "AV Receivers",
  "Cables & Interconnects",
  "Streaming Devices",
  "Subwoofers",
  "Mounts & Stands",
]

export const mockSession: StockSession = {
  id: "ST-2026-0206",
  name: "Q1 Full AV Inventory",
  status: "live",
  startedAt: "2026-02-06T08:00:00Z",
  location: "SoundStage AV - Flagship Store",
  totalItems: 3214,
  countedItems: 2187,
  varianceItems: 53,
  verifiedItems: 2134,
  teamMembers: 8,
}

export const mockTeamMembers: TeamMember[] = [
  {
    id: "tm-1",
    name: "Sarah Chen",
    avatar: "SC",
    role: "Lead Counter",
    zone: "Zone A - TV & Display",
    itemsCounted: 342,
    status: "active",
    lastActive: "Just now",
  },
  {
    id: "tm-2",
    name: "Marcus Webb",
    avatar: "MW",
    role: "Counter",
    zone: "Zone B - Hi-Fi & Audio",
    itemsCounted: 289,
    status: "active",
    lastActive: "1m ago",
  },
  {
    id: "tm-3",
    name: "Priya Patel",
    avatar: "PP",
    role: "Counter",
    zone: "Zone C - Headphones & Portable",
    itemsCounted: 256,
    status: "active",
    lastActive: "Just now",
  },
  {
    id: "tm-4",
    name: "James O'Brien",
    avatar: "JO",
    role: "Verifier",
    zone: "Zone A - TV & Display",
    itemsCounted: 198,
    status: "active",
    lastActive: "3m ago",
  },
  {
    id: "tm-5",
    name: "Ana Rivera",
    avatar: "AR",
    role: "Counter",
    zone: "Zone D - Home Cinema",
    itemsCounted: 312,
    status: "idle",
    lastActive: "8m ago",
  },
  {
    id: "tm-6",
    name: "Tom Nguyen",
    avatar: "TN",
    role: "Counter",
    zone: "Zone E - Cables & Accessories",
    itemsCounted: 178,
    status: "active",
    lastActive: "2m ago",
  },
  {
    id: "tm-7",
    name: "Lisa Park",
    avatar: "LP",
    role: "Supervisor",
    zone: "All Zones",
    itemsCounted: 45,
    status: "active",
    lastActive: "Just now",
  },
  {
    id: "tm-8",
    name: "David Kim",
    avatar: "DK",
    role: "Counter",
    zone: "Zone F - Pro AV & Install",
    itemsCounted: 303,
    status: "offline",
    lastActive: "22m ago",
  },
]

export const mockStockItems: StockItem[] = [
  {
    id: "si-001",
    sku: "TV-OLED-LG-65",
    name: 'LG C4 65" OLED evo 4K TV',
    category: "Televisions",
    location: "Zone A - Bay 2",
    expectedQty: 12,
    countedQty: 11,
    variance: -1,
    status: "variance",
    lastCountedBy: "Sarah Chen",
    lastCountedAt: "09:23 AM",
  },
  {
    id: "si-002",
    sku: "TV-QLED-SAM-75",
    name: 'Samsung QN90D 75" Neo QLED',
    category: "Televisions",
    location: "Zone A - Bay 1",
    expectedQty: 8,
    countedQty: 8,
    variance: 0,
    status: "verified",
    lastCountedBy: "James O'Brien",
    lastCountedAt: "09:18 AM",
  },
  {
    id: "si-003",
    sku: "SPK-KEF-LS50W",
    name: "KEF LS50 Wireless II Speakers",
    category: "Speakers",
    location: "Zone B - Shelf 3",
    expectedQty: 6,
    countedQty: 8,
    variance: 2,
    status: "variance",
    lastCountedBy: "Marcus Webb",
    lastCountedAt: "09:31 AM",
  },
  {
    id: "si-004",
    sku: "HP-SONY-WH1K",
    name: "Sony WH-1000XM5 Headphones",
    category: "Headphones",
    location: "Zone C - Hook Wall 1",
    expectedQty: 45,
    countedQty: 45,
    variance: 0,
    status: "counted",
    lastCountedBy: "Priya Patel",
    lastCountedAt: "09:45 AM",
  },
  {
    id: "si-005",
    sku: "SB-SONOS-ARC",
    name: "Sonos Arc Soundbar",
    category: "Soundbars",
    location: "Zone D - Wall 2",
    expectedQty: 18,
    countedQty: null,
    variance: null,
    status: "pending",
    lastCountedBy: null,
    lastCountedAt: null,
  },
  {
    id: "si-006",
    sku: "CBL-HDMI-8K-3M",
    name: "AudioQuest 48G 8K HDMI Cable 3m",
    category: "Cables & Interconnects",
    location: "Zone E - Rack 1",
    expectedQty: 60,
    countedQty: 55,
    variance: -5,
    status: "variance",
    lastCountedBy: "Tom Nguyen",
    lastCountedAt: "09:12 AM",
  },
  {
    id: "si-007",
    sku: "TV-SONY-A95L-55",
    name: 'Sony A95L 55" QD-OLED TV',
    category: "Televisions",
    location: "Zone A - Bay 3",
    expectedQty: 6,
    countedQty: 6,
    variance: 0,
    status: "verified",
    lastCountedBy: "Sarah Chen",
    lastCountedAt: "09:55 AM",
  },
  {
    id: "si-008",
    sku: "HP-APPLE-APMAX",
    name: "Apple AirPods Max (USB-C)",
    category: "Headphones",
    location: "Zone C - Display 2",
    expectedQty: 24,
    countedQty: null,
    variance: null,
    status: "pending",
    lastCountedBy: null,
    lastCountedAt: null,
  },
  {
    id: "si-009",
    sku: "TT-REGA-P3",
    name: "Rega Planar 3 Turntable",
    category: "Turntables & Vinyl",
    location: "Zone B - Table 1",
    expectedQty: 4,
    countedQty: 3,
    variance: -1,
    status: "variance",
    lastCountedBy: "Marcus Webb",
    lastCountedAt: "08:48 AM",
  },
  {
    id: "si-010",
    sku: "PJ-EPSON-LS12K",
    name: "Epson LS12000 4K Laser Projector",
    category: "Projectors",
    location: "Zone D - Bay 1",
    expectedQty: 3,
    countedQty: 3,
    variance: 0,
    status: "counted",
    lastCountedBy: "Ana Rivera",
    lastCountedAt: "09:38 AM",
  },
  {
    id: "si-011",
    sku: "AVR-DENON-X3800",
    name: "Denon AVR-X3800H AV Receiver",
    category: "AV Receivers",
    location: "Zone D - Shelf 2",
    expectedQty: 10,
    countedQty: null,
    variance: null,
    status: "pending",
    lastCountedBy: null,
    lastCountedAt: null,
  },
  {
    id: "si-012",
    sku: "SPK-BW-802D4",
    name: "Bowers & Wilkins 802 D4 Floorstanders",
    category: "Speakers",
    location: "Zone B - Demo Room",
    expectedQty: 2,
    countedQty: 2,
    variance: 0,
    status: "counted",
    lastCountedBy: "Marcus Webb",
    lastCountedAt: "10:02 AM",
  },
  {
    id: "si-013",
    sku: "STR-APPLE-TV4K",
    name: "Apple TV 4K (3rd Gen)",
    category: "Streaming Devices",
    location: "Zone E - Shelf 4",
    expectedQty: 36,
    countedQty: 36,
    variance: 0,
    status: "verified",
    lastCountedBy: "Priya Patel",
    lastCountedAt: "10:15 AM",
  },
  {
    id: "si-014",
    sku: "SUB-SVS-SB3K",
    name: "SVS SB-3000 Subwoofer",
    category: "Subwoofers",
    location: "Zone D - Bay 3",
    expectedQty: 8,
    countedQty: null,
    variance: null,
    status: "pending",
    lastCountedBy: null,
    lastCountedAt: null,
  },
  {
    id: "si-015",
    sku: "MNT-SANUS-VLF728",
    name: "Sanus VLF728 Full-Motion TV Mount",
    category: "Mounts & Stands",
    location: "Zone E - Rack 5",
    expectedQty: 20,
    countedQty: 22,
    variance: 2,
    status: "variance",
    lastCountedBy: "Tom Nguyen",
    lastCountedAt: "10:22 AM",
  },
]

export const mockActivityFeed: ActivityEvent[] = [
  {
    id: "ev-1",
    type: "count",
    message: "counted 8 OLED TVs in Bay 2",
    user: "Sarah Chen",
    timestamp: "Just now",
    zone: "Zone A",
  },
  {
    id: "ev-2",
    type: "variance",
    message: "flagged variance on KEF LS50 Wireless II (+2)",
    user: "Marcus Webb",
    timestamp: "2m ago",
    zone: "Zone B",
  },
  {
    id: "ev-3",
    type: "verify",
    message: "verified Samsung QN90D 75\" count",
    user: "James O'Brien",
    timestamp: "4m ago",
    zone: "Zone A",
  },
  {
    id: "ev-4",
    type: "count",
    message: "completed headphone hook wall scan",
    user: "Priya Patel",
    timestamp: "6m ago",
    zone: "Zone C",
  },
  {
    id: "ev-5",
    type: "zone_complete",
    message: "Zone C - Hook Wall 1 through 3 complete",
    user: "System",
    timestamp: "8m ago",
    zone: "Zone C",
  },
  {
    id: "ev-6",
    type: "join",
    message: "joined the stock take session",
    user: "Tom Nguyen",
    timestamp: "15m ago",
  },
  {
    id: "ev-7",
    type: "variance",
    message: "flagged variance on HDMI 8K Cables (-5)",
    user: "Tom Nguyen",
    timestamp: "18m ago",
    zone: "Zone E",
  },
  {
    id: "ev-8",
    type: "count",
    message: "counted 3 projectors in Bay 1",
    user: "Ana Rivera",
    timestamp: "20m ago",
    zone: "Zone D",
  },
]
